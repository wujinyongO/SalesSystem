CREATE PROCEDURE add_sellers(IN `_phonenumber` CHAR(11), IN `_windowImage` VARCHAR(255), IN `_password` VARCHAR(255),
                             IN `_state`       INT, IN `_sellername` VARCHAR(255), IN `_windowName` VARCHAR(255))
  BEGIN
insert into sellers(phoneNumber,windowImg,password,state,sellerName,windowName) values(_phonenumber,_windowImage,
_password,_state,_sellername,_windowName);
END;
