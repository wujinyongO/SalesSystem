CREATE PROCEDURE show_all_customers()
  BEGIN
select * from customers;
END;
