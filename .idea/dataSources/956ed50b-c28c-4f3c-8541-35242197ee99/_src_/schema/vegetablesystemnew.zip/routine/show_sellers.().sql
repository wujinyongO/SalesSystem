CREATE PROCEDURE show_sellers()
  BEGIN
select * from sellers;
END;
