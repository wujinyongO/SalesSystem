CREATE PROCEDURE add_customers(IN `_name`     VARCHAR(15), IN `_password` VARCHAR(50), IN `_phonenumber` VARCHAR(11),
                               IN `_imageurl` VARCHAR(100), IN `_address` VARCHAR(100))
  begin
insert into customers(name,password,phonenumber,imageurl,address,visit_made,last_visit_time)
values(_name,_password,_phonenumber,_imageurl,_address,0,current_timestamp());
end;
