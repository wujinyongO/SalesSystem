CREATE PROCEDURE show_vegetable()
  BEGIN
select * from vegetable;
END;
