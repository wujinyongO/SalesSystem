CREATE PROCEDURE show_all_order()
  BEGIN
select o.id,v.foodName,c.name,o.foodNumber,o.create_date,o.getFoodTime 
from vegetableorder o,vegetable v,customers c
where v.id=o.foodId and o.userId=c.id;
END;
