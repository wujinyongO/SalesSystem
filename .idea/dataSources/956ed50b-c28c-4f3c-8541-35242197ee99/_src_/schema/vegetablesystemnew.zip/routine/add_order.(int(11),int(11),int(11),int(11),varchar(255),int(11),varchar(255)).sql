CREATE PROCEDURE add_order(IN `_foodId`      INT, IN `_userId` INT, IN `_foodNumber` INT, IN `_sellerId` INT,
                           IN `_getFoodTime` VARCHAR(255), IN `_isFinish` INT, IN `_foodCode` VARCHAR(255))
  BEGIN
insert into vegetableorder(foodId,userId,foodNumber,sellerId,create_date,getFoodTime,isFinish,foodCode) 
values(_foodId,_userId,_foodNumber,_sellerId,current_timestamp(),_getFoodTime,_isFinish,_foodCode);
END;
