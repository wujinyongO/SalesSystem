CREATE PROCEDURE add_vegetable(IN `_foodImg`   VARCHAR(255), IN `_foodPrice` VARCHAR(128), IN `_foodName` VARCHAR(255),
                               IN `_priceType` VARCHAR(128), IN `_sellerId` INT)
  BEGIN
insert into vegetable(foodImg,foodPrice,foodName,priceType,sellerId) values(_foodImg,_foodPrice,_foodName,_priceType,_sellerId);
END;
