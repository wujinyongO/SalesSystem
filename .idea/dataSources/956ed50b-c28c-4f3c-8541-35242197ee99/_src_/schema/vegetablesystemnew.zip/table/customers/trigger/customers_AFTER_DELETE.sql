CREATE TRIGGER customers_AFTER_DELETE
AFTER DELETE ON customers
FOR EACH ROW
  BEGIN
insert into logs(who,time,table_name,operation,key_value) values(old.name,current_timestamp(),'customers','delete',old.id);
END;
