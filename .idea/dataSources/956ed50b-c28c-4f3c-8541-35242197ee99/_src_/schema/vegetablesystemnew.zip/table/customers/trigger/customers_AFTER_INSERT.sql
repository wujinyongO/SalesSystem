CREATE TRIGGER customers_AFTER_INSERT
AFTER INSERT ON customers
FOR EACH ROW
  BEGIN
insert into logs(who,time,table_name,operation,key_value) values(new.name,current_timestamp(),'customers','insert',new.id);
END;
