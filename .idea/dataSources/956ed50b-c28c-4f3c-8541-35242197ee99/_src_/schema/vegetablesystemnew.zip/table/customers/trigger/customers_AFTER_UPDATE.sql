CREATE TRIGGER customers_AFTER_UPDATE
AFTER UPDATE ON customers
FOR EACH ROW
  BEGIN
insert into logs(who,time,table_name,operation,key_value) values(new.name,current_timestamp(),'customers','update',new.id);
END;
