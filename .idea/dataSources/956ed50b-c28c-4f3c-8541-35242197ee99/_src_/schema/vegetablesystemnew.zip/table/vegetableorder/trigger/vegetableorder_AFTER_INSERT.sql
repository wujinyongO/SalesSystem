CREATE TRIGGER vegetableorder_AFTER_INSERT
AFTER INSERT ON vegetableorder
FOR EACH ROW
  BEGIN
insert into logs(who,time,table_name,operation,key_value) values(new.id,current_timestamp(),'vegetableOrder','insert',new.foodNumber);
END;
