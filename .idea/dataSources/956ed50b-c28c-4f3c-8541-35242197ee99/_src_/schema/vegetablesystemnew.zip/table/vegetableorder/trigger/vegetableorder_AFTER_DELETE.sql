CREATE TRIGGER vegetableorder_AFTER_DELETE
AFTER DELETE ON vegetableorder
FOR EACH ROW
  BEGIN
insert into logs(who,time,table_name,operation,key_value) values(old.id,current_timestamp(),'vegetableOrder','delete',old.foodNumber);
END;
