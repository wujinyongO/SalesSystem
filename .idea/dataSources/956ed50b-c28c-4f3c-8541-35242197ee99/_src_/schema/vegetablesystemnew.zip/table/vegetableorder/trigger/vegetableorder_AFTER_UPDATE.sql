CREATE TRIGGER vegetableorder_AFTER_UPDATE
AFTER UPDATE ON vegetableorder
FOR EACH ROW
  BEGIN
insert into logs(who,time,table_name,operation,key_value) values(new.id,current_timestamp(),'vegetableOrder','update',new.foodNumber);
END;
