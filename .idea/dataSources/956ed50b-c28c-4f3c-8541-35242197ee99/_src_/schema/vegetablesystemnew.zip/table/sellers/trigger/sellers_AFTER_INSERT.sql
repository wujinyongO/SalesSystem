CREATE TRIGGER sellers_AFTER_INSERT
AFTER INSERT ON sellers
FOR EACH ROW
  BEGIN
insert into logs(who,time,table_name,operation,key_value) values(new.sellername,current_timestamp(),'sellers','insert',new.id);
END;
