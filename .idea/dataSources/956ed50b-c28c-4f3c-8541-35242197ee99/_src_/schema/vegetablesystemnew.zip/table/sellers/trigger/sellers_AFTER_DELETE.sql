CREATE TRIGGER sellers_AFTER_DELETE
AFTER DELETE ON sellers
FOR EACH ROW
  BEGIN
insert into logs(who,time,table_name,operation,key_value) values(old.sellername,current_timestamp(),'sellers','delete',old.id);
END;
