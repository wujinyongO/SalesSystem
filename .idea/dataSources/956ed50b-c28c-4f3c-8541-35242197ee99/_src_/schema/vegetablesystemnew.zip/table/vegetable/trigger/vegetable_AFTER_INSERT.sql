CREATE TRIGGER vegetable_AFTER_INSERT
AFTER INSERT ON vegetable
FOR EACH ROW
  BEGIN
insert into logs(who,time,table_name,operation,key_value) values(new.foodname,current_timestamp(),'vegetable','insert',new.id);
END;
