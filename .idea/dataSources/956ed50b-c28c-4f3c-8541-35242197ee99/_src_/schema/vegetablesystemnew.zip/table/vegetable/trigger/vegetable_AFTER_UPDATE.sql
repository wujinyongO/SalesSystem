CREATE TRIGGER vegetable_AFTER_UPDATE
AFTER UPDATE ON vegetable
FOR EACH ROW
  BEGIN
insert into logs(who,time,table_name,operation,key_value) values(new.foodname,current_timestamp(),'vegetable','update',new.id);
END;
