CREATE TRIGGER vegetable_AFTER_DELETE
AFTER DELETE ON vegetable
FOR EACH ROW
  BEGIN
insert into logs(who,time,table_name,operation,key_value) values(old.foodname,current_timestamp(),'vegetable','delete',old.id);
END;
