CREATE PROCEDURE add_cusmoters(IN `_name`     VARCHAR(15), IN `_password` VARCHAR(50), IN `_phonenumber` VARCHAR(11),
                               IN `_imageurl` VARCHAR(100), IN `_address` VARCHAR(100), IN `_visit_made` INT(5))
  begin
insert into customers(name,password,phonenumber,imageurl,address,visit_made,last_visit_time)
values(_name,_password,_phonenumber,_imageurl,_address,_visit_made,current_timestamp());
end;
